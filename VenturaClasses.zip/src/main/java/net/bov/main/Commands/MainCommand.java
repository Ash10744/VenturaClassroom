package net.bov.main.Commands;

public class MainCommand {
}
