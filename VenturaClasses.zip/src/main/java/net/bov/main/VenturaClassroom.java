package net.bov.main;

import org.bukkit.plugin.java.JavaPlugin;

public final class VenturaClassroom extends JavaPlugin {

    @Override
    public void onEnable() {
        // Plugin startup logic

    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }
}
